from src.adapters.repository.shopping_list_repository import ShoppingListRepository
from src.entities.shopping_item import ShoppingItem
from typing import List


class FileShoppingListRepository(ShoppingListRepository):
    def __init__(self):
        """Read file from disk"""
        self.items = [ShoppingItem(1, 'orange juice', 7.50)]

    def get_by_id(self, id_item: int) -> List[ShoppingItem]:
        for item in self.items:
            if item.identify == id_item:
                return [item]
