from abc import ABC, abstractmethod
from typing import List
from src.entities.shopping_item import ShoppingItem


class ShoppingListRepository(ABC):
    @abstractmethod
    def get_by_id(self, id_item: float) -> List[ShoppingItem]:
        raise NotImplementedError()
