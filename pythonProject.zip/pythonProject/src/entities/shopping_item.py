from dataclasses import dataclass


@dataclass
class ShoppingItem:
    identify: int
    name: str
    price: float
