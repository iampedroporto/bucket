from src.adapters.tasks import create_celery_app

celery_app = create_celery_app()

if __name__ == '__main__':
    worker = celery_app.Worker(loglevel='INFO')
    worker.start()
