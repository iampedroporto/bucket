from dataclasses import dataclass


@dataclass
class Aluno:
    uid: int
    nome: str
    idade: int
