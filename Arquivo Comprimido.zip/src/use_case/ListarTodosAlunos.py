from src.entities.aluno import Aluno
from src.adapters.repository.AlunoRepo import AlunoRepo
from typing import List


class ListarTodosAlunos:
    def __init__(self, aluno_repo: AlunoRepo):
        self.aluno_repo = aluno_repo

    def execute(self) -> List[Aluno]:
        return self.aluno_repo.get_todos_alunos()
