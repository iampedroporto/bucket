import time
from src.adapters.repository.AlunoRepo import AlunoRepo


class CalcularNotaALuno:
    def __init__(self, aluno_repo: AlunoRepo):
        self.aluno_repo = aluno_repo

    @staticmethod
    def __simular_processamento_lento() -> bool:
        time.sleep(20)
        return True

    def execute(self) -> bool:
        return self.__simular_processamento_lento()
