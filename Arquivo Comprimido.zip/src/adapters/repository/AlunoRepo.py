from abc import ABC
from src.entities.aluno import Aluno
from typing import List


class AlunoRepo(ABC):
    def get_todos_alunos(self) -> List[Aluno]:
        raise NotImplementedError
