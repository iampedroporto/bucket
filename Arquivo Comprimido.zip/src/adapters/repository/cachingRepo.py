from abc import ABC


class Caching(ABC):

    def set(self, key: str, value: dict) -> bool:
        raise NotImplementedError

    def get(self, key: str) -> dict:
        raise NotImplementedError

    def has_key(self, key: str) -> bool:
        raise NotImplementedError
