from src.adapters.repository.AlunoRepo import AlunoRepo
from src.entities.aluno import Aluno
from typing import List

lista_alunos: List[Aluno] = [Aluno(1, 'Pedro', 28), Aluno(2, 'Ana', 25)]


class AlunoRepoMock(AlunoRepo):

    def __init__(self, config: dict):
        print(config)

    def get_todos_alunos(self) -> List[Aluno]:
        return lista_alunos
