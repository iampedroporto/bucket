from src.adapters.repository.cachingRepo import Caching
import redis


class CachingRedis(Caching):

    def __init__(self, host: str, port: int, db: int):
        self.r = redis.Redis(host=host, port=port, db=db)

    def set(self, key: str, value: dict) -> bool:
        result = self.r.set(key, value)
        return result

    def get(self, key: str) -> dict:
        result = self.r.get(key)
        return dict(result=result)

    def has_key(self, key: str) -> bool:
        result = self.r.exists(key)
        return result
