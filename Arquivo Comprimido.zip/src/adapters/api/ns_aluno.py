from flask_restx import Namespace, Resource
from src.use_case.ListarTodosAlunos import ListarTodosAlunos
from src.adapters.repository.implementation.AlunoRepoMock import AlunoRepoMock
from dataclasses import asdict

ns_aluno = Namespace('aluno', description='aluno informações')


@ns_aluno.route('/')
class AsyncTask(Resource):
    @ns_aluno.doc('lista de todos alunos')
    @ns_aluno.expect()
    def get(self):
        """retorna a lista de todos os alunos"""
        configs = {}
        aluno_repo = AlunoRepoMock(configs)
        listar_todos_alunos = ListarTodosAlunos(aluno_repo)
        alunos = listar_todos_alunos.execute()
        result = [asdict(aluno) for aluno in alunos]
        return dict(result=result)

