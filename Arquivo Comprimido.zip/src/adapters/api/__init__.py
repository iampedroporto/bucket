from flask_restx import Api

from .ns_async_task import ns_async_task
from .ns_aluno import ns_aluno

api = Api(
    title='My Title',
    version='1.0',
    description='A description'
)

api.add_namespace(ns_async_task)
api.add_namespace(ns_aluno)
