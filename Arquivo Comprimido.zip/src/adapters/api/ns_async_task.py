from flask_restx import Namespace, Resource, reqparse
from flask import current_app
import celery.states as states

ns_async_task = Namespace('asynctask', description='add operations')

parser = reqparse.RequestParser()
parser.add_argument('num_one', type=int)
parser.add_argument('num_two', type=int)


@ns_async_task.route('/add')
class AsyncTaskAdd(Resource):
    @ns_async_task.doc('running async task add')
    @ns_async_task.expect(parser)
    def get(self):
        """return id of async task add"""
        args = parser.parse_args()
        task = current_app.celery.send_task('add', args=[args['num_one'], args['num_two']])
        return dict(taskId=str(task.id))


@ns_async_task.route('/calcula-nota')
class AsyncTaskCalculaNota(Resource):
    @ns_async_task.doc('running async task calcula nota')
    def get(self):
        """return id of async task calcula nota"""
        task = current_app.celery.send_task('calcular_nota_aluno', args=[])
        return dict(taskId=str(task.id))


parser_result = reqparse.RequestParser()
parser_result.add_argument('id_task', type=str)


@ns_async_task.route('/result')
class ResultAsyncTask(Resource):
    @ns_async_task.doc('geting task result')
    @ns_async_task.expect(parser_result)
    def get(self):
        """return result of task"""
        args = parser_result.parse_args()
        res = current_app.celery.AsyncResult(args['id_task'])
        return dict(result=res.state) if res.state == states.PENDING else dict(result=res.result)
