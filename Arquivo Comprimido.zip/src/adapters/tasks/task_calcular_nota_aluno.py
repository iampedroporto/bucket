from celery import shared_task
from src.adapters.repository.implementation.AlunoRepoMock import AlunoRepoMock
from src.use_case.CalcularNotaAlunos import CalcularNotaALuno


@shared_task(name='calcular_nota_aluno')
def calcular_nota_aluno():
    configs = {}
    aluno_repo = AlunoRepoMock(configs)
    calc_nota = CalcularNotaALuno(aluno_repo)
    calc_nota.execute()
    return "Finalizado sem erros"
