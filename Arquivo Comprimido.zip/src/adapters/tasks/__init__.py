from celery import Celery


def create_celery_app() -> Celery:
    app = Celery(
        'tasks',
        broker='redis://localhost:6379/0',
        backend='redis://localhost:6379/1',
        include=[
            'src.adapters.tasks.task_mul',
            'src.adapters.tasks.task_sum',
            'src.adapters.tasks.task_calcular_nota_aluno']
    )

    return app
