from flask import Flask
from src.adapters.api import api
from src.adapters.tasks import create_celery_app

app = Flask(__name__)
api.init_app(app)
app.celery = create_celery_app()

if __name__ == "__main__":
    app.run(debug=True)
